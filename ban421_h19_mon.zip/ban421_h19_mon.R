## ---- echo=TRUE----------------------------------------------------------
needed <- c("zoo", "ggraph", "tidygraph", "forcats", "stringr", "dplyr", "purrr", 
            "readr", "tidyr", "tibble", "ggplot2", "tidyverse", "wordcloud", 
            "RColorBrewer", "magrittr", "igraph", "miniCRAN", "XML", "MASS", 
            "BiocManager")


## ---- echo = TRUE--------------------------------------------------------
str(Titanic)


## ---- echo = TRUE--------------------------------------------------------
library(MASS)
data(deaths)
str(deaths)


## ---- echo = FALSE, eval=TRUE, cache=TRUE, results="hide"----------------
library(XML)
tr <- try(xmlTreeParse("trunk_verbose_log_new2.xml"))
tr1 <- xmlChildren(xmlRoot(tr))
revs <- sapply(tr1, function(x) unname(xmlAttrs(x)))
msgs <- sapply(tr1, function(x) xmlValue(xmlChildren(x)[["msg"]]))
authors <- unname(sapply(tr1, function(x) xmlValue(xmlChildren(x)[["author"]])))
dates <- strptime(substring(unname(sapply(tr1, function(x) xmlValue(xmlChildren(x)[["date"]]))), 1, 18), format="%Y-%m-%dT%H:%M:%S", tz="UTC")
years <- format(dates, "%Y")


## ---- echo = FALSE, eval=TRUE, cache=TRUE, results="hide"----------------
n1 <- sub("thomas", "tlumley", authors)
n2 <- sub("martyn", "plummer", n1)
n3 <- sub("^r$", "rgentlem", n2)
n4 <- sub("paul", "murrell", n3)
n5 <- sub("root", "system", n4)
n6 <- sub("apache", "system", n5)
authors <- factor(n6)
ad_tab <- table(authors, years)
rs <- rowSums(ad_tab)


## ---- fig1, out.width='90%', fig.align='center', width=7, height=4-------
pal <- scan("colormap_hex.txt", "character", quiet=TRUE)
set.seed(1)
pal_s <- sample(sample(pal))
plot(1998:2018, colSums(ad_tab)[2:22], type="b", xlab="", ylab="SVN commits", ylim=c(0, 4000))
grid()
abline(v=c(2000.1639344, 2004.7568306, 2013.2547945), col=pal_s[1:3], lwd=2)
legend("topright", legend=c("1.0.0 2000-02-29", "2.0.0 2004-10-04", "3.0.0 2013-04-03"), col=pal_s[1:3], bty="n", cex=0.8, lty=1, lwd=2)


## ---- fig2, out.width='90%', fig.align='center', width=7, height=4-------
ors <- order(rs)
barplot(ad_tab[ors[11:28],], col=pal_s[6:23])
legend("topright", legend=rev(rownames(ad_tab)[ors[11:28]]), ncol=4, fill=rev(pal_s[6:23]), cex=0.8, bty="n")


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tr1[[1]]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tr1[[length(tr1)]]


## ---- echo = FALSE, eval=TRUE, cache=TRUE, results="hide"----------------
res <- vector(mode="list", length=length(tr1))
for (i in seq_along(tr1)) res[[i]] <- {x=xmlChildren(xmlChildren(tr1[[i]])[["paths"]]); list(paths=unname(sapply(x, xmlValue)), actions=unname(sapply(x, function(y) xmlAttrs(y)["action"])))}
names(res) <- revs
rl <- sapply(res, function(x) length(x$actions))


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
cat(paste(years[order(rl, decreasing=TRUE)][1:10], revs[order(rl, decreasing=TRUE)][1:10], sort(unname(rl), decreasing=TRUE)[1:10], unname(unlist(sub("\\n", ", ", msgs[order(rl, decreasing=TRUE)])))[1:10]), sep="\n")


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
res50 <- res[rl < 50]
rl_50 <- rl[rl < 50]
f_50 <- unlist(sapply(res50, "[", 1))
a_50 <- unlist(sapply(res50, "[", 2))
a_50_actions <- unname(a_50)
f_50_files <- unname(f_50)
f_50_filesa <- substring(f_50_files, 2, nchar(f_50_files))
f_50_filesb <- strsplit(f_50_filesa, "/")
f_50_filesc <- t(sapply(f_50_filesb, function(x) {out <- character(9); out[1:length(x)] <- x; out}))
files_df <- data.frame(f_50_filesc)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tx <- table(files_df$X2)
sort(tx[tx>350])


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tx <- table(files_df[files_df$X2=="src",]$X3)
sort(tx[tx>50])


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tx <- table(files_df[files_df$X2=="src" & files_df$X3=="library",]$X4)
sort(tx[tx>200])


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tx <- table(files_df[files_df$X2=="src" & files_df$X3=="library" & files_df$X4=="base",]$X5)
sort(tx[tx>4])


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
a_50_revs <- rep(names(rl_50), times=rl_50)
o <- match(a_50_revs, revs)
a_50_years <- years[o]
t_acts <- table(a_50_years, factor(a_50_actions))


## ---- fig3, out.width='90%', fig.align='center', width=7, height=4-------
set.seed(5)
cols <- sample(pal_s, 4)
barplot(t(t_acts), col=cols)
legend("topright", legend=c("A The item was added", "D The item was deleted", "M The item was changed", "R The item was replaced"), ncol=2, fill=cols, cex=0.8, bty="n")


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
BCrepos <- BiocManager::repositories()
bioc <- available.packages(repo = BCrepos[1])
bioc_ann <- available.packages(repo = BCrepos[2])
bioc_exp <- available.packages(repo = BCrepos[3])
cran <- available.packages()
pdb <- rbind(cran, bioc, bioc_ann, bioc_exp)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
suppressPackageStartupMessages(library(miniCRAN))
suppressPackageStartupMessages(library(igraph))
suppressPackageStartupMessages(library(magrittr))
pg <- makeDepGraph(pdb[, "Package"], availPkgs = pdb, suggests=FALSE, enhances=TRUE, includeBasePkgs = FALSE)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
pr <- pg %>%
page.rank(directed = FALSE) %>%
use_series("vector") %>%
sort(decreasing = TRUE) %>%
as.matrix %>%
set_colnames("page.rank")


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
print(pr[1:20,], digits=4)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
cutoff <- quantile(pr[, "page.rank"], probs = 0.2)
popular <- pr[pr[, "page.rank"] >= cutoff, ]
toKeep <- names(popular)
vids <- V(pg)[toKeep]
gs <- induced.subgraph(pg, vids = toKeep)
cl <- walktrap.community(gs, steps = 3)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
topClusters <- table(cl$membership) %>%
sort(decreasing = TRUE) %>%
head(25)
cluster <- function(i, clusters, pagerank, n=10){
group <- clusters$names[clusters$membership == i]
pagerank[group, ] %>% sort(decreasing = TRUE) %>% head(n)}
z <- lapply(names(topClusters)[1:15], cluster, clusters=cl, pagerank=pr, n=80)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
z[[1]][1:12]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
z[[2]][1:12]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
z[[3]][1:12]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
z[[4]][1:12]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tmp <- z[[5]][1:12]
names(tmp) <- substring(names(tmp), 1, 15)
tmp


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
z[[6]][1:12]


## ---- fig4, out.width='90%', fig.align='center', width=7, height=4-------
library(RColorBrewer)
library(wordcloud)
opar <- par(mar=c(0,0,0,0)+0.1, mfrow=c(1,2))
for (i in 1:2) wordcloud(names(z[[i]]), freq=unname(z[[i]]), scale=rev(7*range(unname(z[[i]]))/max(unname(z[[4]]))))
par(opar)


## ---- fig5a, out.width='90%', fig.align='center', width=7, height=4------
opar <- par(mar=c(0,0,0,0)+0.1, mfrow=c(1,2))
for (i in 3:4) wordcloud(names(z[[i]]), freq=unname(z[[i]]), scale=rev(7*range(unname(z[[i]]))/max(unname(z[[4]]))))
par(opar)


## ---- fig5b, out.width='90%', fig.align='center', width=7, height=4------
opar <- par(mar=c(0,0,0,0)+0.1, mfrow=c(1,2))
for (i in 5:6) wordcloud(names(z[[i]]), freq=unname(z[[i]]), scale=rev(7*range(unname(z[[i]]))/max(unname(z[[4]]))))
par(opar)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
pdb0 <- tools::CRAN_package_db()
url <- url("https://Bioconductor.org/packages/release/bioc/VIEWS")
dcf <- as.data.frame(read.dcf(url), stringsAsFactors=FALSE)
close(url)
url_ann <- url("https://Bioconductor.org/packages/release/data/annotation/VIEWS")
dcf_ann <- as.data.frame(read.dcf(url_ann), stringsAsFactors=FALSE)
close(url_ann)
url_exp <- url("https://Bioconductor.org/packages/release/data/experiment/VIEWS")
dcf_exp <- as.data.frame(read.dcf(url_exp), stringsAsFactors=FALSE)
close(url_exp)
o1 <- intersect(names(dcf_exp), names(dcf_ann))
dcf2 <- rbind(dcf_exp[,o1], dcf_ann[,o1])
o2 <- intersect(names(dcf), names(dcf2))
dcf3 <- rbind(dcf2[,o2], dcf[,o2])
o3 <- intersect(names(pdb0), names(dcf3))
pdb <- rbind(pdb0[o3], dcf3[o3])
#o3 <- intersect(names(pdb0), names(dcf))
#pdb <- rbind(pdb0[o3], dcf[o3])
#pdb <- tools::CRAN_package_db()
aut <- pdb$Author


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(stringr))
suppressPackageStartupMessages(library(igraph))
suppressPackageStartupMessages(library(tidygraph))
suppressPackageStartupMessages(library(ggraph))
suppressPackageStartupMessages(library(magrittr))


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
aut <- aut %>%
  str_replace_all("\\(([^)]+)\\)", "") %>%
  str_replace_all("\\[([^]]+)\\]", "") %>%
  str_replace_all("<([^>]+)>", "") %>%
  str_replace_all("\n", " ") %>%
  str_replace_all("[Cc]ontribution.* from|[Cc]ontribution.* by|[Cc]ontributors", " ") %>%
  str_replace_all("\\(|\\)|\\[|\\]", " ") %>%
  iconv(to = "ASCII//TRANSLIT") %>%
  str_replace_all("'$|^'", "") %>%
  gsub("([A-Z])([A-Z]{1,})", "\\1\\L\\2", ., perl = TRUE) %>%
  gsub("\\b([A-Z]{1}) \\b", "\\1\\. ", .) %>%
  map(str_split, ",|;|&| \\. |--|(?<=[a-z])\\.| [Aa]nd | [Ww]ith | [Bb]y ", simplify = TRUE) %>%
  map(str_replace_all, "[[:space:]]+", " ") %>%
  map(str_replace_all, " $|^ | \\.", "") %>%
  map(function(x) x[str_length(x) != 0]) %>%
  set_names(pdb$Package) #%>%
  #extract(map_lgl(., function(x) length(x) > 1))
aut <- aut[sapply(aut, function(x) length(x) > 1)]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
aut_list <- aut %>%
  unlist() %>%
  dplyr::as_data_frame() %>%
  count(value) %>%
  rename(Name = value, Package = n)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
edge_list <- aut %>%
  map(combn, m = 2) %>%
  do.call("cbind", .) %>%
  t() %>%
  dplyr::as_data_frame() %>%
  arrange(V1, V2) %>%
  count(V1, V2)


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
g <- edge_list %>%
  select(V1, V2) %>%
  as.matrix() %>%
  graph.edgelist(directed = FALSE) %>%
  as_tbl_graph() %>%
  activate("edges") %>%
  mutate(Weight = edge_list$n) %>%
  activate("nodes") %>%
  rename(Name = name) %>%
  mutate(Component = group_components()) %>%
  filter(Component == names(table(Component))[which.max(table(Component))])


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
suppressMessages(g <- g %>%
  left_join(aut_list) %>%
  filter(Package > 4) %>%
  mutate(Component = group_components()) %>%
  filter(Component == names(table(Component))[which.max(table(Component))]))


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
g <- mutate(g, Community = group_edge_betweenness(),
            Degree = centrality_degree())


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
lapply(1:6, function(i) {filter(g, Community == names(sort(table(Community), decr = TRUE))[i]) %>%
select(Name, Package) %>%
arrange(desc(Package)) %>%
top_n(100, Package) %>% as.data.frame()}) -> comms


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
comms[[1]][1:12,]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
comms[[2]][1:12,]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tmp <- comms[[3]][1:12,]
tmp[,1] <- substring(tmp[,1], 1, 20)
tmp


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
comms[[4]][1:12,]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
comms[[5]][1:12,]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
tmp <- comms[[6]][1:12,]
tmp[,1] <- substring(tmp[,1], 1, 20)
tmp


## ---- fig6, , out.width='90%', fig.align='center', width=7, height=4-----
opar <- par(mar=c(0,0,0,0)+0.1, mfrow=c(1,2))
for (i in 1:2) wordcloud(comms[[i]]$Name, freq=comms[[i]]$Package, scale=rev(2*range(comms[[i]]$Package)/max(comms[[1]]$Package)))
par(opar)


## ---- fig7a, eval=TRUE, , out.width='90%', fig.align='center', width=7, height=4----
opar <- par(mar=c(0,0,0,0)+0.1, mfrow=c(1,2))
for (i in 3:4) wordcloud(comms[[i]]$Name, freq=comms[[i]]$Package, scale=rev(2*range(comms[[i]]$Package)/max(comms[[1]]$Package)))
par(opar)


## ---- fig7b, eval=TRUE, , out.width='90%', fig.align='center', width=7, height=4----
opar <- par(mar=c(0,0,0,0)+0.1, mfrow=c(1,2))
for (i in 5:6) wordcloud(comms[[i]]$Name, freq=comms[[i]]$Package, scale=rev(2*range(comms[[i]]$Package)/max(comms[[1]]$Package)))
par(opar)


## ----calc2, echo = TRUE--------------------------------------------------
2+3
7*8
3^2
log(1)
log10(10)


## ----calc1, echo = TRUE--------------------------------------------------
print(2+3)
print(sqrt(2))
print(sqrt(2), digits=10)
print(10^7)


## ----calc3, echo = TRUE--------------------------------------------------
log(0)
sqrt(-1)
1/0
0/0


## ----ass1, echo = TRUE---------------------------------------------------
a <- 2+3
a
is.finite(a)
a <- log(0)
is.finite(a)


## ----vect1, echo = TRUE--------------------------------------------------
a <- c(2, 3)
a
sum(a)
str(a)
aa <- rep(a, 50)
aa


## ----vect2, echo = TRUE--------------------------------------------------
length(aa)
aa[1:10]
sum(aa)
sum(aa[1:10])
sum(aa[-(11:length(aa))])


## ----vect2a, echo = TRUE-------------------------------------------------
a[1] + a[2]
sum(a)
`+`(a[1], a[2])
Reduce(`+`, a)


## ----vect3, echo = TRUE--------------------------------------------------
sum(aa)
sum(aa+2)
sum(aa)+2
sum(aa*2)
sum(aa)*2


## ----vect4, echo = TRUE--------------------------------------------------
v5 <- 1:5
v2 <- c(5, 10)
v5 * v2
v2_stretch <- rep(v2, length.out=length(v5))
v2_stretch
v5 * v2_stretch


## ----NA, echo = TRUE-----------------------------------------------------
anyNA(aa)
is.na(aa) <- 5
aa[1:10]
anyNA(aa)
sum(aa)
sum(aa, na.rm=TRUE)


## ----check1, echo = TRUE-------------------------------------------------
big <- 1:(10^5)
length(big)
head(big)
str(big)
summary(big)


## ----coerce1, echo = TRUE------------------------------------------------
set.seed(1)
x <- runif(50, 1, 10)
is.numeric(x)
y <- rpois(50, lambda=6)
is.numeric(y)
is.integer(y)
xy <- x < y
is.logical(xy)


## ----coerce2, echo = TRUE------------------------------------------------
str(as.integer(xy))
str(as.numeric(y))
str(as.character(y))
str(as.integer(x))


## ---- echo = TRUE--------------------------------------------------------
V1 <- 1:3
V2 <- letters[1:3]
V3 <- sqrt(V1)
V4 <- sqrt(as.complex(-V1))
L <- list(v1=V1, v2=V2, v3=V3, v4=V4)


## ---- echo = TRUE--------------------------------------------------------
str(L)
L$v3[2]
L[[3]][2]


## ---- echo = TRUE--------------------------------------------------------
DF <- as.data.frame(L)
str(DF)
DF <- as.data.frame(L, stringsAsFactors=FALSE)
str(DF)


## ---- echo = TRUE--------------------------------------------------------
V2a <- letters[1:4]
V4a <- factor(V2a)
La <- list(v1=V1, v2=V2a, v3=V3, v4=V4a)
DFa <- try(as.data.frame(La, stringsAsFactors=FALSE), silent=TRUE)
message(DFa)


## ---- echo = TRUE--------------------------------------------------------
DF$v3[2]
DF[[3]][2]
DF[["v3"]][2]


## ---- echo = TRUE--------------------------------------------------------
DF[2, 3]
DF[2, "v3"]
str(DF[2, 3])
str(DF[2, 3, drop=FALSE])


## ---- echo = TRUE--------------------------------------------------------
as.matrix(DF)
as.matrix(DF[,c(1,3)])


## ---- echo = TRUE--------------------------------------------------------
length(L)
length(DF)
length(as.matrix(DF))


## ---- echo = TRUE--------------------------------------------------------
dim(L)
dim(DF)
dim(as.matrix(DF))


## ---- echo = TRUE--------------------------------------------------------
str(as.matrix(DF))


## ---- echo = TRUE--------------------------------------------------------
row.names(DF)
names(DF)
names(DF) <- LETTERS[1:4]
names(DF)
str(dimnames(as.matrix(DF)))


## ---- echo = TRUE--------------------------------------------------------
str(attributes(DF))
str(attributes(as.matrix(DF)))


## ---- echo = TRUE--------------------------------------------------------
V1a <- c(V1, NA)
V3a <- sqrt(V1a)
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a)
DFa <- as.data.frame(La, stringsAsFactors=FALSE)
str(DFa)


## ----factor1, echo = TRUE------------------------------------------------
gen <- c("female", "male", NA)
fgen <- factor(gen)
str(fgen)
nlevels(fgen)
levels(fgen)
as.integer(fgen)
levels(fgen)[as.integer(fgen)]


## ----factor2, echo = TRUE------------------------------------------------
status <- c("Lo", "Hi", "Med", "Med", "Hi")
ordered.status <- ordered(status, levels=c("Lo", "Med", "Hi"))
ordered.status
str(ordered.status)
table(status)
table(ordered.status)


## ---- echo = TRUE--------------------------------------------------------
strsplit(Sys.getlocale(), ";")


## ---- echo = TRUE--------------------------------------------------------
V5 <- c("æ", "Æ", "ø", "å")
sapply(V5, charToRaw)
V6 <- iconv(V5, to="CP1252")
sapply(V6, charToRaw)


## ---- echo = TRUE--------------------------------------------------------
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a, v5=V5, v6=V6)
DFa <- as.data.frame(La)
str(DFa)


## ---- echo = TRUE--------------------------------------------------------
now <- Sys.time()
now
class(now)
as.Date(now)
unclass(now)


## ---- echo = TRUE--------------------------------------------------------
str(unclass(as.POSIXlt(now)))


## ---- echo = TRUE--------------------------------------------------------
suppressMessages(library(zoo))
as.yearmon(now)
as.yearqtr(now)
as.Date("2016-03-01") - 1 # day
as.Date("2018-03-01") - 1 # day


## ---- echo = TRUE--------------------------------------------------------
seq(as.Date(now), as.Date(now)+12, length.out=4)


## ----sI, echo = TRUE-----------------------------------------------------
sessionInfo()

