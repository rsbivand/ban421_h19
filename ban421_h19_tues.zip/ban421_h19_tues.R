

## ---- echo=TRUE----------------------------------------------------------
needed <- c("rbenchmark", "wrapr", "magrittr", "lme4", "reticulate", "Matrix",
            "mgcv", "nlme", "Rcpp", "lattice", "MASS", "grid_3.6.1", "jsonlite",
            "minqa", "nloptr", "boot", "splines", "tools", "compiler", "BiocManager")


## ---- echo = TRUE--------------------------------------------------------
methods(as.data.frame)


## ---- echo = TRUE--------------------------------------------------------
data(mtcars)
class(mtcars)
attributes(mtcars)


## ---- echo = TRUE--------------------------------------------------------
(oS <- search())


## ---- echo = TRUE--------------------------------------------------------
library(mgcv)
gm <- gam(formula=mpg ~ s(wt), data=mtcars)
class(gm)
print(gm)


## ---- echo = TRUE--------------------------------------------------------
stats:::print.glm(gm)


## ---- echo = TRUE--------------------------------------------------------
methods(logLik)


## ---- echo = TRUE--------------------------------------------------------
nS <- search()
nS[!(nS %in% oS)]


## ---- echo = FALSE, eval=TRUE, cache=TRUE--------------------------------
BCrepos <- BiocManager::repositories()
bioc <- available.packages(repo = BCrepos[1])
bioc_ann <- available.packages(repo = BCrepos[2])
bioc_exp <- available.packages(repo = BCrepos[3])
bioc_db <- rbind(bioc, bioc_ann, bioc_exp)
cran_db <- available.packages()


## ---- echo = TRUE, cache=TRUE--------------------------------------------
cran_deps <- grep("methods", cran_db[, "Depends"])
cran_imps <- grep("methods", cran_db[, "Imports"])
cran_methods_packages <- cran_db[unique(sort(c(cran_deps, cran_imps))), "Package"]
nrow(cran_db)
length(cran_methods_packages)

## ---- echo = TRUE, cache=TRUE--------------------------------------------
bioc_deps <- grep("methods", bioc_db[, "Depends"])
bioc_imps <- grep("methods", bioc_db[, "Imports"])
bioc_methods_packages <- bioc_db[unique(sort(c(bioc_deps, bioc_imps))), "Package"]
nrow(bioc_db)
length(bioc_methods_packages)


## ---- echo = TRUE--------------------------------------------------------
cran_deps <- grep("Rcpp", cran_db[, "Depends"])
cran_imps <- grep("Rcpp", cran_db[, "Imports"])
cran_lt <- grep("Rcpp", cran_db[, "LinkingTo"])
cran_Rcpp_packages <- cran_db[unique(sort(c(cran_deps, cran_imps, cran_lt))), "Package"]
cran_Rcpp_methods_packages <- intersect(cran_methods_packages, cran_Rcpp_packages)
length(cran_Rcpp_packages)
length(cran_Rcpp_methods_packages)


## ---- echo = TRUE--------------------------------------------------------
bioc_deps <- grep("Rcpp", bioc_db[, "Depends"])
bioc_imps <- grep("Rcpp", bioc_db[, "Imports"])
bioc_lt <- grep("Rcpp", bioc_db[, "LinkingTo"])
bioc_Rcpp_packages <- bioc_db[unique(sort(c(bioc_deps, bioc_imps, bioc_lt))), "Package"]
bioc_Rcpp_methods_packages <- intersect(bioc_methods_packages, bioc_Rcpp_packages)
length(bioc_Rcpp_packages)
length(bioc_Rcpp_methods_packages)


## ---- echo = TRUE--------------------------------------------------------
d100 <- diag(100)
isS4(d100)
str(d100)
object.size(d100)


## ---- echo = TRUE--------------------------------------------------------
getClass(class(d100))


## ---- echo = TRUE--------------------------------------------------------
library(Matrix)
D100 <- Diagonal(100)
isS4(D100)
str(D100)
object.size(D100)


## ---- echo = TRUE--------------------------------------------------------
getClass(class(D100))


## ---- echo = TRUE--------------------------------------------------------
showMethods(f=coerce, classes=class(D100))


## ---- echo = TRUE--------------------------------------------------------
str(as(D100, "dgeMatrix"))


## ---- echo = TRUE--------------------------------------------------------
deps <- grep("R6", cran_db[, "Depends"])
imps <- grep("R6", cran_db[, "Imports"])
R6_packages <- cran_db[unique(sort(c(deps, imps))), "Package"]
length(R6_packages)


## ---- echo = TRUE--------------------------------------------------------
cran_db["reticulate", c("Depends", "Imports", "LinkingTo")]
cran_db["jsonlite", c("Depends", "Imports", "LinkingTo")]
cran_db["Rcpp", c("Depends", "Imports", "LinkingTo")]
cran_db["Matrix", c("Depends", "Imports", "LinkingTo")]


## ---- echo = TRUE--------------------------------------------------------
library(reticulate)
os <- import("os")
os$getcwd()
np <- import("numpy", convert = FALSE)
a <- np$array(c(1:4))
a
py_to_r(a)
sum <- a$cumsum()
sum
py_to_r(sum)
cumsum(c(1:4))


## ---- echo = TRUE--------------------------------------------------------
library(mgcv)
f <- mpg ~ s(wt)
gm <- gam(formula=f, data=mtcars)
gm1 <- gam(update(f, . ~ - s(wt) + poly(wt, 3)), data=mtcars)
anova(gm, gm1, test="Chisq")


## ---- echo = TRUE--------------------------------------------------------
mtcars$fcyl <- as.factor(mtcars$cyl)
f1 <- update(f, log(.) ~ - s(wt) - 1 + wt + fcyl)
f1
lm(f1, data=mtcars)


## ---- echo = TRUE--------------------------------------------------------
terms(f1)


## ---- echo = TRUE--------------------------------------------------------
head(model.matrix(f1, mtcars))


## ---- echo = TRUE--------------------------------------------------------
model.response(model.frame(f1, mtcars))[1:6]
mtcars$mpg[1:6]
log(mtcars$mpg[1:6])


## ---- echo = TRUE--------------------------------------------------------
library(lme4)
lmm <- lmer(update(f, log(.) ~ poly(wt, 3) | fcyl), mtcars)
fixef(lmm)
ranef(lmm)


## ---- echo = TRUE--------------------------------------------------------
mtcars$fam <- as.factor(mtcars$am)
lm(update(f, log(.) ~ - s(wt) + (fam*fcyl)/wt - 1), mtcars)


## ---- echo = TRUE--------------------------------------------------------
xtabs(~ fam + fcyl, data=mtcars)
row.names(mtcars)[mtcars$am == 1]


## ---- echo = TRUE--------------------------------------------------------
require


## ---- echo = TRUE--------------------------------------------------------
ggplot2 <- "gridExtra"
ggplot2
ggplot2 <- as.character(substitute(ggplot2))
ggplot2
paste0("package:", ggplot2) %in% search()


## ---- echo = TRUE--------------------------------------------------------
subset(mtcars, subset=cyl == 4)


## ---- echo = TRUE--------------------------------------------------------
acyl <- "cyl"
ncyl <- 4
mtcars[mtcars[[acyl]] == ncyl,]


## ---- echo = TRUE--------------------------------------------------------
is.list(mtcars)
mtcars[eval(substitute(cyl == 4), mtcars, parent.frame()), ]


## ---- echo = TRUE--------------------------------------------------------
create_form = function(power){
 rhs = substitute(I(hp^pow), list(pow=power))
 as.formula(paste0("mpg ~ ", deparse(rhs)))
}
list_formulae = Map(create_form, seq(1,6))
  # mapply(create_form, seq(1,6))
llm <- lapply(list_formulae, lm, data=mtcars)
sapply(llm, function(x) summary(x)$sigma)


## ---- echo = TRUE--------------------------------------------------------
(lns <- readLines(pipe("dir")))
lns <- sort(do.call("c", strsplit(lns, " +")))


## ---- echo = TRUE--------------------------------------------------------
con <- file(lns[3])
readLines(con, n=6L)
close(con)


## ---- echo = TRUE--------------------------------------------------------
library(magrittr)
magrittr:::'%>%'


## ---- echo = TRUE--------------------------------------------------------
library(wrapr)
library(rbenchmark);
benchmark(SE=cos(exp(sin(4))),
          "dot-pipe"=4 %.>% sin(.) %.>% exp(.) %.>% cos(.),
          "bizarro-pipe"={4 ->.; sin(.) ->.; exp(.) ->.; cos(.)},
          "magrittr-pipe"=4 %>% sin() %>% exp() %>% cos(),
          replications=10000, order="elapsed")


## ---- echo = TRUE--------------------------------------------------------
chain_parts <- readRDS("chain_parts.rds")
str(chain_parts)
object.size(chain_parts)


## ----sI, echo = TRUE-----------------------------------------------------
sessionInfo()

