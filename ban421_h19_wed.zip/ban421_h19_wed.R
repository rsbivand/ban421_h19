

## ---- echo=TRUE----------------------------------------------------------
needed <- c("rgdal", "spdep", "sf", "spData", "sp", "WDI", "wbstats", "eurostat", "SmarterPoland", "htmltools", "httr", "ggplot2", "rbenchmark", "readstata13", "foreign", "DBI", "RSQLite", "feather", "data.table", "readr")


## ---- echo = TRUE--------------------------------------------------------
if (!file.exists("outdata")) dir.create("outdata")
set.seed(123)
df <- data.frame(replicate(10, sample(0:2000, 15 * 10^5, rep = TRUE)),
                 replicate(10, stringi::stri_rand_strings(1000, 5)))
dim(df)


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(write.table(df, file="outdata/df.txt", row.names = FALSE))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(write.csv2(df, file = "outdata/df2.csv", row.names = FALSE))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readr)
system.time(write_csv(df, path = "outdata/df.csv"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(data.table)
system.time(fwrite(df, file = "outdata/df_dt.csv", row.names=FALSE))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
file.info(paste("outdata", list.files("outdata"), sep="/"))[,1, drop=FALSE]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(save(df, file="outdata/df_gz6.rda", compress="gzip", compression_level=6))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(save(df, file="outdata/df_gz0.rda", compress="gzip", compression_level=0))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(saveRDS(df, file="outdata/df.rds"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(feather)
system.time(write_feather(df, "outdata/df.feather"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
file.info(paste("outdata", list.files("outdata"), sep="/"))[,1, drop=FALSE]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(RSQLite)
library(DBI)
con <- dbConnect(RSQLite::SQLite(), "outdata/df.sqlite")
system.time(dbWriteTable(con, "df", df, overwrite=TRUE))
dbDisconnect(con)


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(foreign)
system.time(write.dta(df, file="outdata/df.dta"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readstata13)
system.time(save.dta13(df, file="outdata/df_s13.dta"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
file.info(paste("outdata", list.files("outdata"), sep="/"))[,1, drop=FALSE]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.table("outdata/df.txt", header=TRUE))
class(df_in)
head(df_in[,c(1, 11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.table("outdata/df.txt", header=TRUE, stringsAsFactors=FALSE))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.csv2("outdata/df2.csv"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.csv2("outdata/df2.csv", stringsAsFactors=FALSE))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readr)
system.time(suppressMessages(df_in <- read_csv2("outdata/df2.csv", progress = FALSE)))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(data.table)
system.time(df_in <- fread("outdata/df_dt.csv", showProgress = FALSE))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(rbenchmark);
res <- benchmark("CSV_factor"=read.csv2("outdata/df2.csv"),
          "CSV"=read.csv2("outdata/df2.csv", stringsAsFactors=FALSE),
          "readr_CSV"=suppressMessages(read_csv2("outdata/df2.csv", progress = FALSE)),
          "fread_CSV"=fread("outdata/df_dt.csv", showProgress = FALSE),
          replications=10, order="elapsed")


## ---- echo = TRUE, cache=TRUE--------------------------------------------
res[,1:4]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time({load("outdata/df_gz6.rda"); df_in <- df})
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time({load("outdata/df_gz0.rda"); df_in <- df})
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- readRDS("outdata/df.rds"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(feather)
system.time(df_in <- read_feather("outdata/df.feather"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(foreign)
system.time(df_in <- read.dta("outdata/df.dta"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readstata13)
system.time(df_in <- read.dta13("outdata/df_s13.dta"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(RSQLite)
library(DBI)
con <- dbConnect(RSQLite::SQLite(), "outdata/df.sqlite")
system.time(df_in <- dbReadTable(con, "df"))
dbDisconnect(con)
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
res <- benchmark("SQLite"={con <- dbConnect(RSQLite::SQLite(), "outdata/df.sqlite");
       system.time(df_in <- dbReadTable(con, "df")); dbDisconnect(con)},
       "Stata"=read.dta("outdata/df.dta"),
       "Stata13"=read.dta("outdata/df.dta"),
       "feather"=read_feather("outdata/df.feather"),
       "RDS"=readRDS("outdata/df.rds"),
       "RDA0"=load("outdata/df_gz0.rda"),
       "RDA6"=load("outdata/df_gz6.rda"),
       replications=10, order="elapsed")


## ---- echo = TRUE, cache=TRUE--------------------------------------------
res[,1:4]


## ---- echo = TRUE--------------------------------------------------------
suppressMessages(library(SmarterPoland))
tmp <- grepEurostatTOC("regional")
str(tmp)
demo_r_gind3 <- getEurostatRCV(kod="demo_r_gind3")
levels(demo_r_gind3$indic_de)


## ---- echo = TRUE--------------------------------------------------------
suppressMessages(library(eurostat))
toc <- get_eurostat_toc()
str(toc)


## ---- echo=TRUE----------------------------------------------------------
df <- get_eurostat("tgs00026", time_format = "raw")
df$time <- eurotime2num(df$time)


## ---- echo = TRUE--------------------------------------------------------
suppressMessages(library("wbstats"))
pop_gdp_data <- wb(country = c("PL"), indicator = c("SP.POP.TOTL", "NY.GDP.MKTP.CD"),
startdate = 1990, enddate = 2016)
head(pop_gdp_data)


## ---- echo = TRUE--------------------------------------------------------
suppressMessages(library("WDI"))
res <- WDIsearch('gdp')
str(res)


## ---- echo = TRUE, cache=TRUE--------------------------------------------
suppressMessages(library(spdep))
suppressMessages(require(rgdal, quietly=TRUE))
wheat <- readOGR(system.file("shapes/wheat.shp", package="spData"), verbose=FALSE)
nbr1 <- poly2nb(wheat, queen=FALSE)
nbrl <- nblag(nbr1, 2)
nbr12 <- nblag_cumul(nbrl)
cms0 <- with(as(wheat, "data.frame"), tapply(yield, c, median))
cms1 <- c(model.matrix(~ factor(c) -1, data=wheat) %*% cms0)
wheat$yield_detrend <- wheat$yield - cms1
RNGkind("L'Ecuyer-CMRG")
set.seed(1L)
system.time(boot_out_ser <- aple.mc(as.vector(scale(wheat$yield_detrend, scale=FALSE)),
 nb2listw(nbr12, style="W"), nsim=10000))


## ---- echo = TRUE--------------------------------------------------------
suppressMessages(library(spdep))
library(parallel)
nc <- detectCores(logical=FALSE)
nc
invisible(set.coresOption(nc))
set.seed(1L)
system.time({if (!get.mcOption()) {
  cl <- makeCluster(nc, "PSOCK")
  set.ClusterOption(cl)
} else{
  mc.reset.stream()
}
boot_out_par <- aple.mc(as.vector(scale(wheat$yield_detrend, scale=FALSE)),
    nb2listw(nbr12, style="W"), nsim=10000)
if (!get.mcOption()) {
  set.ClusterOption(NULL)
  stopCluster(cl)
}})


## ---- echo = TRUE--------------------------------------------------------
system.time({if (!get.mcOption()) {
  cl <- makeCluster(nc, "FORK")
  set.ClusterOption(cl)
} else{
  mc.reset.stream()
}
boot_out_par <- aple.mc(as.vector(scale(wheat$yield_detrend, scale=FALSE)),
    nb2listw(nbr12, style="W"), nsim=10000)
if (!get.mcOption()) {
  set.ClusterOption(NULL)
  stopCluster(cl)
}})


## ----sI, echo = TRUE-----------------------------------------------------
sessionInfo()

