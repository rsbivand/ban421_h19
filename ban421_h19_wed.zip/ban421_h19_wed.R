

## ---- echo=TRUE----------------------------------------------------------
needed <- c("rgdal", "spdep", "sf", "spData", "sp", "WDI", "wbstats", "eurostat", "SmarterPoland", "htmltools", "httr", "ggplot2", "rbenchmark", "readstata13", "foreign", "DBI", "RSQLite", "feather", "data.table", "readr")


## ---- echo = TRUE--------------------------------------------------------
if (!file.exists("outdata")) dir.create("outdata")
set.seed(123)
df <- data.frame(replicate(10, sample(0:2000, 15 * 10^5, rep = TRUE)),
                 replicate(10, stringi::stri_rand_strings(1000, 5)))
dim(df)


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(write.table(df, file="outdata/df.txt", row.names = FALSE))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(write.csv2(df, file = "outdata/df2.csv", row.names = FALSE))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readr)
system.time(write_csv(df, path = "outdata/df.csv"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(data.table)
system.time(fwrite(df, file = "outdata/df_dt.csv", row.names=FALSE))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
file.info(paste("outdata", list.files("outdata"), sep="/"))[,1, drop=FALSE]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(save(df, file="outdata/df_gz6.rda", compress="gzip", compression_level=6))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(save(df, file="outdata/df_gz0.rda", compress="gzip", compression_level=0))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(saveRDS(df, file="outdata/df.rds"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(feather)
system.time(write_feather(df, "outdata/df.feather"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
file.info(paste("outdata", list.files("outdata"), sep="/"))[,1, drop=FALSE]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(RSQLite)
library(DBI)
con <- dbConnect(RSQLite::SQLite(), "outdata/df.sqlite")
system.time(dbWriteTable(con, "df", df, overwrite=TRUE))
dbDisconnect(con)


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(foreign)
system.time(write.dta(df, file="outdata/df.dta"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readstata13)
system.time(save.dta13(df, file="outdata/df_s13.dta"))


## ---- echo = TRUE, cache=TRUE--------------------------------------------
file.info(paste("outdata", list.files("outdata"), sep="/"))[,1, drop=FALSE]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.table("outdata/df.txt", header=TRUE))
class(df_in)
head(df_in[,c(1, 11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.table("outdata/df.txt", header=TRUE, stringsAsFactors=FALSE))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.csv2("outdata/df2.csv"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- read.csv2("outdata/df2.csv", stringsAsFactors=FALSE))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readr)
system.time(suppressMessages(df_in <- read_csv2("outdata/df2.csv", progress = FALSE)))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(data.table)
system.time(df_in <- fread("outdata/df_dt.csv", showProgress = FALSE))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(rbenchmark);
res <- benchmark("CSV_factor"=read.csv2("outdata/df2.csv"),
          "CSV"=read.csv2("outdata/df2.csv", stringsAsFactors=FALSE),
          "readr_CSV"=suppressMessages(read_csv2("outdata/df2.csv", progress = FALSE)),
          "fread_CSV"=fread("outdata/df_dt.csv", showProgress = FALSE),
          replications=10, order="elapsed")


## ---- echo = TRUE, cache=TRUE--------------------------------------------
res[,1:4]


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time({load("outdata/df_gz6.rda"); df_in <- df})
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time({load("outdata/df_gz0.rda"); df_in <- df})
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
system.time(df_in <- readRDS("outdata/df.rds"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(feather)
system.time(df_in <- read_feather("outdata/df.feather"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(foreign)
system.time(df_in <- read.dta("outdata/df.dta"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(readstata13)
system.time(df_in <- read.dta13("outdata/df_s13.dta"))
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
library(RSQLite)
library(DBI)
con <- dbConnect(RSQLite::SQLite(), "outdata/df.sqlite")
system.time(df_in <- dbReadTable(con, "df"))
dbDisconnect(con)
class(df_in)
head(df_in[,c(1,11)])


## ---- echo = TRUE, cache=TRUE--------------------------------------------
res <- benchmark("SQLite"={con <- dbConnect(RSQLite::SQLite(), "outdata/df.sqlite");
       system.time(df_in <- dbReadTable(con, "df")); dbDisconnect(con)},
       "Stata"=read.dta("outdata/df.dta"),
       "Stata13"=read.dta("outdata/df.dta"),
       "feather"=read_feather("outdata/df.feather"),
       "RDS"=readRDS("outdata/df.rds"),
       "RDA0"=load("outdata/df_gz0.rda"),
       "RDA6"=load("outdata/df_gz6.rda"),
       replications=10, order="elapsed")


## ---- echo = TRUE, cache=TRUE--------------------------------------------
res[,1:4]


## ----sI, echo = TRUE-----------------------------------------------------
sessionInfo()

